public interface ProcessTile {
    public void process(Map map, Tile tile);
}
