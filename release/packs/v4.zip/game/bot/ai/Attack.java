package game.bot.ai;

public class Attack {

    public void pickTargets() {
	
    }
}
