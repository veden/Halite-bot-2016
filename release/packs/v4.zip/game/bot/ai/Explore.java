package game.bot.ai;

public class Explore {

    public void pickTargets() {

    }
}
