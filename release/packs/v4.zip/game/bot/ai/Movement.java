package game.bot.ai;

public class Movement {

    public void pickTargets() {

    }
}
