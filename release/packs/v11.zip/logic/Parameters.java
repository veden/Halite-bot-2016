package logic;

public class Parameters {
    public static float generatorWeight = 0.28f; //0.42f;
    public static float siteCostWeight = 0.7f; //0.63f;
    public static float sitePotentialWeight = 0.41f; //0.33f;
    public static float siteCountWeight = 0.76f; //0.46f;
    public static float generatorTotalWeight = 0.61f; //0.05f;
}
