package logic;

public class Parameters {
    public static float generatorWeight = 0.20f;
    public static float siteCostWeight = 0.6f;
    public static float sitePotentialWeight = 0.2f;
    public static float siteCountWeight = 0.25f;
    public static float generatorTotalWeight = 0.25f;
}
